This directory contains files/directories for development purposes, including tests that are important but should not be included in R CMD check.
